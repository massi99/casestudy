import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BannerImageRoutingModule } from './banner-image-routing.module';
import { BannerImageComponent } from './banner-image.component';


@NgModule({
  declarations: [
    BannerImageComponent
  ],
  imports: [
    CommonModule,
    BannerImageRoutingModule
  ]
})
export class BannerImageModule { }
