import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentMarksInfoRoutingModule } from './student-marks-info-routing.module';
import { StudentMarksInfoComponent } from './student-marks-info.component';


@NgModule({
  declarations: [
    StudentMarksInfoComponent
  ],
  imports: [
    CommonModule,
    StudentMarksInfoRoutingModule
  ]
})
export class StudentMarksInfoModule { }
