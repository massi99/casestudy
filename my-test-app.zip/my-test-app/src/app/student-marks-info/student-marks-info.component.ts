import { Component, OnInit } from '@angular/core';
import { Student } from '../Model/Student';
import { StudentInfoService } from '../services/studentInfoService';

@Component({
  selector: 'app-student-marks-info',
  templateUrl: './student-marks-info.component.html',
  styleUrls: ['./student-marks-info.component.scss'],
  providers: [StudentInfoService],
})
export class StudentMarksInfoComponent implements OnInit {
  studentInfoMarks: Student[] = [];
  tempMarksInfo: Student[] = [];
  headingInfoMap = new Map();
  currentOrder: string = 'normal';
  prevOrder: any;
  prevHeader: any;
  constructor(private studentInfoService: StudentInfoService) {}

  ngOnInit(): void {
    this.studentInfoService.getStudentInfo().subscribe((studentInfo) => {
      this.studentInfoMarks = studentInfo.studentsDetails;

      this.tempMarksInfo = [...this.studentInfoMarks];
      if (this.studentInfoMarks.length > 0) {
        this.getTableHeadings(this.studentInfoMarks[0]);
      }
    });
  }
  public getTableHeadings(studentInfo: Student) {
    Object.keys(studentInfo).forEach((x, index) => {
      this.headingInfoMap.set(index, x);
    });
  }

  public sort(header: number) {
    if (this.currentOrder === 'normal') {
      this.currentOrder = 'asc';
    } else if (this.currentOrder === 'asc') {
      this.currentOrder = 'desc';
    } else if (this.currentOrder === 'desc') {
      this.currentOrder = 'normal';
      this.tempMarksInfo = [...this.studentInfoMarks];
      return;
    }

    this.tempMarksInfo = this.tempMarksInfo.sort((a, b) => {
      if (
        a[this.headingInfoMap.get(header) as keyof Student] >
        b[this.headingInfoMap.get(header) as keyof Student]
      ) {
        if (this.currentOrder === 'asc') return 1;
        else {
          return -1;
        }
      }
      if (this.currentOrder === 'asc') return -1;
      else {
        return 1;
      }
    });
  }
}
