import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentMarksInfoComponent } from './student-marks-info.component';

describe('StudentMarksInfoComponent', () => {
  let component: StudentMarksInfoComponent;
  let fixture: ComponentFixture<StudentMarksInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentMarksInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentMarksInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
