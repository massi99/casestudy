
export interface Student{
    name:string;
    class:string;
    section:string;
    sub1:number;
    sub2:number;
    sub3:number;
}