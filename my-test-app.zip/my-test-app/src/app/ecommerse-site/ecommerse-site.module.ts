import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EcommerseSiteRoutingModule } from './ecommerse-site-routing.module';
import { EcommerseSiteComponent } from './ecommerse-site.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [EcommerseSiteComponent],
  imports: [CommonModule, EcommerseSiteRoutingModule, FormsModule],
})
export class EcommerseSiteModule {}
