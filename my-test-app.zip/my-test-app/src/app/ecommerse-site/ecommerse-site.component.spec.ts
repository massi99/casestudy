import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EcommerseSiteComponent } from './ecommerse-site.component';

describe('EcommerseSiteComponent', () => {
  let component: EcommerseSiteComponent;
  let fixture: ComponentFixture<EcommerseSiteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EcommerseSiteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EcommerseSiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
