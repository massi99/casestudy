import { Component, OnInit } from '@angular/core';
import { Product } from '../Model/Product';
import { ProductService } from '../services/productService';

@Component({
  selector: 'app-ecommerse-site',
  templateUrl: './ecommerse-site.component.html',
  styleUrls: ['./ecommerse-site.component.scss'],
  providers: [ProductService],
})
export class EcommerseSiteComponent implements OnInit {
  constructor(private productService: ProductService) {}
  selectedPrice: number = 0;
  productsArray: Product[] = [];
  originalProducts: Product[] = [];
  priceList = [20000, 40000, 60000, 80000, 100000, 200000];

  ngOnInit(): void {
    this.productService.getProducts().subscribe((data) => {
      this.originalProducts = data.products;
      this.productsArray = this.originalProducts;
    });
  }

  public filterProducts() {
    return (this.productsArray = this.originalProducts
      .sort((a, b) => b.price - a.price)
      .filter((p) => p.price <= this.selectedPrice));
  }

  public listView(event: any) {
    let wrapperElement = document.querySelector('.wrapper');

    wrapperElement?.classList.add('list');
  }
  public gridView(event: any) {
    let wrapperElement = document.querySelector('.wrapper');

    wrapperElement?.classList.remove('list');
  }
}
