import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TimerAppServiceComponent } from './timer-app-service.component';

const routes: Routes = [{ path: '', component: TimerAppServiceComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TimerAppServiceRoutingModule { }
