import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class TimerService {
  counter = new BehaviorSubject<number>(0);
  startedTime = new BehaviorSubject<Date | null>(null);
  pausedTime = new BehaviorSubject<Date | null>(null);
  startCount = new BehaviorSubject<number>(0);
  pausedCount = new BehaviorSubject<number>(0);
}
