import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimerAppServiceComponent } from './timer-app-service.component';

describe('TimerAppServiceComponent', () => {
  let component: TimerAppServiceComponent;
  let fixture: ComponentFixture<TimerAppServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TimerAppServiceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TimerAppServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
