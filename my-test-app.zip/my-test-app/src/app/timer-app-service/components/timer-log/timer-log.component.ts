import { Component, Input, OnInit } from '@angular/core';
import { TimerService } from '../../service/timerService';

@Component({
  selector: 'app-timer-log',
  templateUrl: './timer-log.component.html',
  styleUrls: ['./timer-log.component.scss'],
})
export class TimerLogComponent implements OnInit {
 

  constructor(public timerService:TimerService) {}

  ngOnInit(): void {}
}
