import { Component, Input, OnInit } from '@angular/core';
import { TimerService } from '../../service/timerService';

@Component({
  selector: 'app-timer-display',
  templateUrl: './timer-display.component.html',
  styleUrls: ['./timer-display.component.scss'],
})
export class TimerDisplayComponent {
  constructor(public timerService: TimerService) {}
}
