import { Component, Input, OnInit } from '@angular/core';
import { TimerService } from '../../service/timerService';

@Component({
  selector: 'app-timer-count',
  templateUrl: './timer-count.component.html',
  styleUrls: ['./timer-count.component.scss']
})
export class TimerCountComponent  {

  constructor (public timerService:TimerService){}

  


}
