import { Component, OnInit } from '@angular/core';
import {
  BehaviorSubject,
  interval,
  Observable,
  repeatWhen,
  Subscription,
  takeWhile,
} from 'rxjs';
import { TimerService } from './service/timerService';

@Component({
  selector: 'app-timer-app-service',
  templateUrl: './timer-app-service.component.html',
  styleUrls: ['./timer-app-service.component.scss'],
  providers: [TimerService],
})
export class TimerAppServiceComponent {
  initialCountLimit: number = 0;
  isCounterActive: boolean = false;
  originalValue: number = 0;
  notPaused$ = new BehaviorSubject<boolean>(true);
  notStop$ = new BehaviorSubject<boolean>(true);
  start$ = new BehaviorSubject<boolean>(true);
  timerObservale$: Observable<any>;
  subscription1$: Subscription | undefined;

  constructor(private timerService: TimerService) {
    this.timerObservale$ = interval(1000).pipe(
      takeWhile((x) => this.notStop$.value === true),
      takeWhile((x) => this.notPaused$.value === true),
      repeatWhen(() => this.start$)
    );
  }
  //start/ stop counter
  counterStartPause() {
    if (this.isCounterActive && this.timerService.counter.value > 0) {
      if (this.notPaused$.value) {
        this.timerService.pausedTime.next(new Date());
        this.notPaused$.next(false);
        this.timerService.pausedCount.next(
          this.timerService.pausedCount.value + 1
        );
      } else {
        this.start$.next(true);
        this.notPaused$.next(true);
        this.timerService.startCount.next(
          this.timerService.startCount.value + 1
        );
        this.timerService.startedTime.next(new Date());
      }
    } else {
      if (
        this.initialCountLimit == 0 &&
        this.timerService.counter.value !== 0 &&
        !this.isCounterActive
      ) {
        this.initialCountLimit = this.timerService.counter.value;
      }
      if (this.initialCountLimit !== 0 && this.initialCountLimit > 0) {
        this.resetObservables();
        this.timerService.startCount.next(1);
        this.timerService.startedTime.next(new Date());
        this.timerService.counter.next(this.initialCountLimit);
        this.originalValue = this.initialCountLimit;
        this.subscription1$ = this.timerObservale$.subscribe(() => {
          if (this.timerService.counter.value > 0) {
            this.timerService.counter.next(this.timerService.counter.value - 1);
          } else {
            this.notStop$.next(false);
            this.isCounterActive = false;
          }
        });
        this.isCounterActive = true;
        this.initialCountLimit = 0;
      }
    }
  }

  resetObservables() {
    this.notStop$.next(true);
    this.notPaused$.next(true);
    this.start$.next(true);
  }
  //reset counter
  counterReset() {
    this.timerService.counter.next(this.originalValue);
    this.initialCountLimit = 0;
    this.notStop$.next(false);
    this.isCounterActive = false;
    this.timerService.startCount.next(0);
    this.timerService.pausedCount.next(0);
    this.timerService.pausedTime.next(null);
    this.timerService.startedTime.next(null);
    this.subscription1$?.unsubscribe();
  }
}
